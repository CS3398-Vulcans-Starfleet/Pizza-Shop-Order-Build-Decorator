package patternsexamp;

import java.awt.*;        // Using AWT container and component classes
import java.awt.event.*;  // Using AWT event classes and listener interfaces
import java.io.*;



public class PizzaToppings {

	public boolean pepperoni = false;
	public boolean onion = false;
	public boolean frenchfries = false;
}
 
     